Stride_Data Python Library

This is the Python library that contains the necessary analysis helper functions and database
helper functions.

How to install this library.
1. Ensure that Python >= 3.6 is installed. Instructions to install [here]().
2. Ensure that the Python library pip is installed. Instructions to install [here]().
3. Ensure that the C library libpq-dev is installed on your computer.
4. Install library using this command `pip install stride_data_0.0.1-py3-none-any.whl`.
